Please see PyRECONSTRUCT's GitHub page for the most detailed & up-to-date instructions:
https://github.com/wtrdrnkr/pyrecon